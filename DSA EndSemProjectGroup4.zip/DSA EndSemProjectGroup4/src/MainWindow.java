public class MainWindow {
    public static void main(String[] args) {
        try {
            new Frames();
        } catch (Exception e) {
            javax.swing.JOptionPane.showMessageDialog(null, "Unexcepted Error");
        }
    }
}